import React from 'react';
import {
    View,
    Text
} from 'react-native';

const Search = () => {
    return (
        <View>
            <Text>Search</Text>
        </View>
    )
}

export default Search;