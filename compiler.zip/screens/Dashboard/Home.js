import React from 'react';
import {
    View,
    Text
} from 'react-native';

const Home = () => {
    return (
        <View>
            <Text>Home</Text>
        </View>
    )
}

export default Home;