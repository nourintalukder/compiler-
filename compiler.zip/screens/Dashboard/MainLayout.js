import React from 'react';
import {
    View,
    Text
} from 'react-native';

const MainLayout = () => {
    return (
        <View>
            <Text>MainLayout</Text>
        </View>
    )
}

export default MainLayout;